# zoo.py task 11.1
def hours():
    print('Open 9-5 daily')
    
