# 11.5
plain = {'a': 1, 'b': 2, 'c': 3}
for i in plain:
    print(i)

print(plain)

# 11.6
from collections import OrderedDict
fancy = OrderedDict(plain)
for i in fancy:
    print(i)

print(fancy)

# 11.7
from collections import defaultdict
dict_of_lists = defaultdict(list)
dict_of_lists['a'] = 'something for a'
print(dict_of_lists['a'])
print(dict_of_lists)
