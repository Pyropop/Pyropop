#Dictionaries and sets - Chapter 8
empty_dict = {}
bierce = {
    "day": "A period of twenty-four hours, mostly misspent",
    "positive": "Mistaken at the top of one's voice",
    "misfortune": "The kind of fortune that never misses",
    }
print(bierce)
acme_customer = {'first': 'Wile', 'middle': 'E', 'last': 'Coyote'}
some_pythons = {
    'Graham': 'Chapman',
    'John': 'Cleese',
    'Eric': 'Idle',
    'Terry': 'Gilliam',
    'Michael': 'Palin',
    'Terry': 'Jones',
    }
print(some_pythons)
# 8.1
e2f = dict(dog="chien", cat="chat", walrus="morse")
print(e2f)
# 8.2
print(e2f['walrus'])
# 8.3
english = []
for keys in e2f:
    print(keys)
    english.append(keys)
french = []
for values in e2f.values():
    print(values)
    french.append(values)
print(french, english)
f2e = dict( zip(french, english) )
print(f2e)
# 8.4
print(f2e['chien'])
# 8.5
print(english)
# 8.6
life = {'animals': {'cats': ['Henri', 'Grumpy', 'Lucy'], 'octopi':{}, 'emus':{} } , 'plants':{}, 'other':{}}
# 8.7
print(life.keys())
# 8.8
print(life['animals'].keys())
# 8.9
print(life['animals']['cats'])
# 8.10 Dictionary comprehension with range(10)to dict(squares) and square of each key as its' value
# {key_expression : value_expression for expression in iterable if condition}
squares = {square: 2 for square in life if range(10) * 2}
print(squares)


