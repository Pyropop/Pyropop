# Chapter 12 Things to Do
# 12.1 Find Unicode
import unicodedata
def unicode(value):
    name = unicodedata.name(value)
    value2 = unicodedata.lookup(name)
    print('value="%s", name="%s", value2="%s"' % (value, name, value2))
mystery = unicode('\U0001f984')
mystery = '\U0001f984'
print(mystery, unicodedata.name(mystery))

# 12.2 Encoding to utf-8
print(mystery)
pop_bytes = mystery.encode('utf-8')
print(pop_bytes)

# 12.3 Decode bytes to pop_string in utf-8
pop_string = pop_bytes.decode('utf-8')
print(pop_string)
if pop_string == mystery:
    print("It's true")

# 12.4 https://bit.ly/mcintyre-poetry

source = mammoth.txt
print(source)
# 12.5 Importin re tp findall words starting with 'c'
import re
findc = re.findall('c', source)
findc
